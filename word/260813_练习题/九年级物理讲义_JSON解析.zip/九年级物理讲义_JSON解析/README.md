# 试题JSON解析包

- `questions/question_001.json` 至 `question_277.json`：每道题一个JSON文件。
- `all_questions.json`：整份讲义的合并JSON。
- `all_questions.jsonl`：适合批量导入的JSONL。
- `assets/`：题图和公式图片。
- `manifest.json`：文件清单与解析说明。

字段包括：题干、选项、子问题、答案、解析、插图、表格、公式资源、来源定位及质量警告。

## 重要说明

当前原Word为题目讲义，未检索到明确的“答案/解析”栏目。为避免擅自推断，所有题目的 `answer.raw` 与 `analysis` 均保留为空，并在 `quality.warnings` 中标记。若需要，可在此解析包基础上继续补全标准答案与逐题解析。
